// Package core implements essential parts of Shadowsocks
package core
