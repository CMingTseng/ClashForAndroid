// Package shadowstream implements the original Shadowsocks protocol protected by stream cipher.
package shadowstream
