# Tun2Socket

A utilize that use kernel tcpip stack to forward packet from tun device.

### Feature

- IPv4
- TCP/UDP
- Ping Echo
