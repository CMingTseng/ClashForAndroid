# DHCPv6 client

A minimal DHCPv6 client can be implemented in a few lines of code, by using the default
client parameters. The example in [main.go](./main.go) lets you specify the
interface to send packets through, and defaults to `eth0`.
