## Contributors

* Andrea Barberio (main author)
* Pablo Mazzini (tons of fixes and new options)
* Sean Karlage (BSDP package, and of tons of improvements to the DHCPv4 package)
* Owen Mooney (several option fixes and modifiers)
* Mikolaj Walczak (asynchronous DHCPv6 client)
* Chris Koch (tons of improvements in DHCPv4 and DHCPv6 internals and interface)
* Akshay Navale, Brandon Bennett and Chris Gorham (ZTPv6 and ZTPv4 packages)
* Anatole Denis (tons of fixes and new options)
